WELCOME TO THE SFM Web App files

upon opening the file, you will see:

- extra 
pages we couldn't successfully integrate for reasons

- images 
the images we would use in our pages

- Main 
the first pages you should open, WE STRONGLY RECOMMEND YOU START WITH THIS FILE

- Managment 
the pages that fall under the management section will all belong in this file

- Market 
pages that have to do with the marketplace section will be in this file

- Social 
the Social hub and it's pages would belong here

- SQL
our SQL database CREATE and INSERT queries will all be stored here, IT IS NECESSARY TO RUN THESE QUERIES FOR THE WEB APP TO FUNCTION

- Available logins
a list of available accounts to log in to use the web app

---------------------------------------------------------------------------------------------------------------------------------------
DO keep the file as 
wamp64 > www > SFM >
for the file src to work properly

IF YOU HAVE ANY TROUBLE SETTING IT UP
NOTIFY ME 
Melvin Lee Ming Xuan
TP068939@mail.apu.edu.my 
